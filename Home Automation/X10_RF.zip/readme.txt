Here is a solution if you want to use a RF remote to control X10 devices. 

The original X10 RF remotes use NEC codes transmitted over different carrier
frequencies. Read in the included file to find out more about the used
frequencies and codes. 

If you�re lucky having a RF remote which uses the same frequency as your X10 
transceiver - this upgrade should work for you. If not - you might still use 
the Powermid to convert the IR code into a proper RF signal. The Powermid is 
rather cheaper compared with the IR543 normally used for this purpose.

In the upgrade file are defined ON/OFF functions for devices 1-8, house code 
"M". If you want to use devices 9-16 or change the house code enter the 
"Device Number" from the following table in "Protocol parameters" group on 
the "Setup" page in RemoteMaster. Note that the functions BRIGHT/DIM and 
ALL ON/ALL OFF cannot be used when the "Device Number" for devices 9-16 is 
selected. 


HouseCode Device Hex       HouseCode Device Hex
--------- ------ ---       --------- ------ ---
A1-A8        6    9F       I1-I8        7    1F
A9-A16      38    9B       I9-I16      39    1B
B1-B8       14    8F       J1-J8       15    0F
B9-B16      46    8b       J9-J16      47    0B
C1-C8        2    BF       K1-K8        3    3F
C9-C16      34    BB       K9-K16      35    3B
D1-D8       10    AF       L1-L8       11    2F
D9-D16      42    AB       L9-L16      43    2B
E1-E8        1    7F       M1-M8        0    FF
E9-E16      33    7B       M9-M16      32    FB
F1-E8        9    6F       N1-N8        8    EF
F9-E16      41    6B       N9-N16      40    EB
G1-G8        5    5F       O1-O8        4    DF
G9-G16      37    5B       O9-O16      36    DB
H1-H8       13    4F       P1-P8       12    CF
H9-H16      45    4B       P9-P16      44    CB



Enjoy!
