These files are provided to assist in using your PCTV 800i TV Tuner
card with Windows Media Center in Windows 7. I found the included
TVCenter application buggy and had trouble getting a good non-
interlaced picture. Windows Media Center handles the hardware much
better in my case and is more functional than TVCenter.

There is a RemoteMaster upgrade file if you wish to
customize the defined functions or match to your remote. 
This RemoteMaster file was created with RemoteMaster 1.97 and
configured to work with a URC-8910 (New) remote, but will work with
Others. The RemoteMaster OBC values match the KEY number values in 
the included profiles.ini file.

Save and replace your original profiles.ini file usually
located in <drive>\ProgramData\PCTV Systems\RemoTerm\Profiles with 
the included file. Edit the file to setup your own Media Center 
launch from the POWER button if you wish or to change/add key 
numbers to match your remote.

When you installed the PCTV drivers and software, it included a very
useful program called "remoterm.exe". This program is configured to
take inputs from the PCTV IR reader, that plugs into the PCTV card,
and issue either direct program or keyboard commands to TVCenter or
Media Center applications. It is usually configured to auto-start
and has a little remote icon in the system tray. If you select or 
rt-mouse on it, you can change some settings, but most useful in
configuring your remote, is a "Test" feature. This brings up a test
dialog which shows that it is receiving your remote commands and then
shows the command code/number that it receives. This number is then 
used in the profiles.ini file to issue the appropriate application
commands. There is a good site that I used to get started.

http://www.dvbviewer.tv/forum/topic/9721-pinnacle-remote-control-type-b-usb-400e-for-dvb/

