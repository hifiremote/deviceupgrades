The upgrade was setup for the URC-2056 Titan remote and will provide mouse movement, some VLC hotkeys, and some Firefox keyboard shortcuts.  These are just keyboard commands, so will have function in other programs and areas of Windows.


I used one the the MCE upgrades that Robman posted but any upgrade or built-in code would work.  Just make sure it doesn't send signals that other home theater equipment would respond to.  The actual functions that the remote sends for the upgrade are irrevelant, the signal is what will be learned in Flirc and assigned to whatever Windows keybord command you want.  For instance, the letter A function can be assigned to the Channel + button but then be recorded in Flirc to send the keyboard command for the number 7.

The mouse keys needed to be setup through the CLI interface of Flirc- flirc_util.exe.  Remember to run from the Flirc installation folder or add the installation folder to PATH.

An example of the mouse key hid decimal code for mouse up is:
flirc_util.exe record_api 0 96
The CLI will then ask for the remote button to be pressed for this code.

The hid decimal codes for the mouse keys are in brackets in the Notes column.

The rest of the keys can be setup through the GUI.  CTRL + ESC is used in the Flirc GUI for the Windows menu.

It should be possible to load the upgrade into a remote and load the Flirc config inot Flirc GUI and be ready to go.  Make sure to turn on Mouse Keys in Windows 10, adjust the settings to your preference, and test on the number pad before testing the remote.

Note: some remotes (like the 2056) require the shift button to be pressed twice to use the shifted number commands.