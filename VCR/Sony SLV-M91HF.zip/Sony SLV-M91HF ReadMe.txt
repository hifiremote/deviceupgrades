Sony SLV-M91HF VCR Setup (Keymap Master v5.04b)
Mike England (mr_d_p_gumby)

This ZIP file contains three setups for the Sony VCRs.

If your VCR has a switch to select the remote code
as VTR1, VTR2 or VTR3, use the appropriate setup sheet.

If your changer does not have a switch, then the sheet
for VTR3 will probably be the correct one to use.

The button codes in these setup sheets were obtained from
several different Sony VCR models, and will probably work
for most recent Sony VCRs, though some models may have
additional functions that you will have to research.
