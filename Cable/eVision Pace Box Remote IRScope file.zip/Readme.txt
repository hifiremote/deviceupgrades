Remote control files for Slingbox / Etisalat eVision Pace (eurostar) DIP7910

Not all keys are mapped! - Only current active keys (As of August 2013) 

Source files are there if you need to modify anything

.ict 				- Original scan of all buttons from DIP7910 remote control - done wth IRScope and IR Widget

.bin files 			- use directly

.rmdu 				- Open in RemoteMaster to change layouts or add other keys

Append to Protocol dot ini.txt 	- Text file with the MCE "Non Repeating" setup - Open "Protocols.ini" in your RemoteMaster dir - and append included text from "append file" - else you might get "double tap's" on the arrow keys.
