Anyway, I finally downloaded ALL of Yamaha's Hex code crap, it comes in annoying PDF files mostly
this database was downloaded completly on 11/15/07

the PDFs will explain the rest, there is also some CML files and MXF files too.. i don't care much about those so i wont document any of it. but it is complete.




the code in the PDFs will look like this

MAIN POWER ON 7E-7E

open the file irhex_converter.html in your browser and 

VERY IMPORTANT

**enter the code *WITHOUT* the - replace it with a space so it looks like 7E 7E

the program will spit out the hex needed for most remote software like theatertouch for RTI

0000 006D 0022 0002 0155 00AA 0015 0015 0015 0040 0015 0040 0015 0040 0015 0040 0015 0040 0015 0040 0015 0015 0015 0040 0015 0015 0015 0015 0015 0015 0015 0015 0015 0015 0015 0015 0015 0040 0015 0015 0015 0040 0015 0040 0015 0040 0015 0040 0015 0040 0015 0040 0015 0015 0015 0040 0015 0015 0015 0015 0015 0015 0015 0015 0015 0015 0015 0015 0015 0040 0015 05ED 0155 0055 0015 0E47 

have fun