These are the two files I use on my Sony 740 receiver.

Your receiver must be set to AV1 mode and not AV2 mode for these to work.

Basically, I have all the buttons setup in a keymaster upgrade for the main device.  This is the Sony AV1 Protocol 16 and 144 file.  I do keymoves in IR on L1, L2, L3, PIP, Move, and Swap for my input selections, so they are not mapped to buttons on the KM upgrade file.

Then, I use the Sony AV1 Protocol 12 and 13 upgrade file so I can do keymoves to the f.fwd button and f.rew button for Scan + and Scan -.  I also mapped AM/FM to the TV/Vid button.

I think that should explain everything.