Receiver: Pioneer VSX-D510 A/V Multi-Channel Receiver
DVD/CD: Pioneer DV-302D three disc changer

Open file Pioneer rcvr 0013.rmdu using RM.  This is a 'Pioneer 3DEV' code that I have spent many hours on while learning the intricacies of the Pioneer codes.  Hopefully my efforts can save someone else a few hours of 'fun' anyway.  MANY thanks to Rob Crowe (of course!) and Neil Coig for pointing me in the right direction and of course all of the others involved in the entire JP1 effort.  The fine work done by this group never ceases to blow my mind.  Notes on this file follow:

Devices 164 and 165 are used to access the receiver functions.

Device 163 is used to access the dvd player transport functions.

You can see how the various devices are selected by checking out the OBC2 column on the 'Functions' tab.

Unfortunately, the dvd transport signals are the only ones accessible with nice clean one-byte signals.  Many (most) of the other DVD functions are of the 'Pioneer DVD' type, which use two device codes and one 'parm' (163-175-153 - what the heck does 'parm' stand for anyway???), and as such cannot be directly accessed by this upgrade spreadsheet.  Therefore I am also including in this zip file a copy of my RMIR download which details the advanced codes which are necessary to add some of the other dvd functions to the receiver device (descriptions below).  It is named simply "Pioneer - rev 28.rmir" and should be opened using the RMIR program.  (There's also a few learned commands to get the receiver volume functions mapped to the dvd device.  Just wanted to use up some learned memory space to balance things out a little.  Plus (if memory serves), I had a %#$@^ of a time trying to program those functions as advanced codes, it's one of those Pioneer things I guess...........)

(My primary goal was to put as many of both the dvd and receiver functions under the receiver device of my Cinema 7+ so as to not have to keep shifting back and forth between the dvd and receiver devices.  I think the combination of this km spreadsheet and the few learned functions have pretty well accomplished this goal.  The only time it is absolutely necessary to access the dvd function is to use the arrow keys to navigate the various dvd menus.)

Check it out if you are so inclined and enjoy!  I know I did!  (But my wife thinks I've long since lost it....)

TBone in New Hampshire (need me to fix any Epi reactors???)

DVD Advanced codes (using Pioneer DVD protocol) mapped to following RCV buttons (see Keymoves tab of file "Pioneer - rev 28.rmir" opened with RMIR):

MACRO1 = EFC 160 = angle
MACRO2 = EFC 150 = subtitle
PIP On/off = EFC 153 = disc 1 select
PIP Swap = EFC 151 = disc 2 select
PIP Move = EFC 155 = disc 3 select
Display = EFC 029 = step/slow reverse
Enter = EFC 162 = step/slow forward
TV/VCR = EFC 077 = repeat a-b
Record = EFC 028 = power

PS - Rob - sorry if I got any of the nomenclature wrong............

PPS - Still looking for those discrete power codes for my brandy-new Sharp TV (to make my macros that much better), any help out there?????

