Pioneer VSX-45TX Elite (and family) Device Codes

BACKGROUND:
There are THREE device code files included; The "amp", the "tuner" and "combo" (which combines both functions).  The "combo" SHOULD be all that we need, however it uses protocol "Pioneer 3DEV" and this protocol loses a bit or two from some commands thus NOT ALL FUNCTIONS WORK with the "combo" device upgrade.  Its frustrating because only 8 functions fail and if these functions are not important to you then you may simply use the "combo" upgrade and be fine.  However, most of us will need 1 or more of these broken functions so I included the "amp" and "tuner" parts as separate device upgrades so you can keymove to combine them however you wish.  You could also use the combo upgrade and just keymove the "amp" functions that don't work in the combo upgrade.

NOTES:
I included some codes for the 47TX model though I have not tested them myself (since I have a 45TX).  These codes may also work on the VSX-41/43/49 models as well.  Perhaps this .zip will someday contain specific upgrades for each model.  Feel free to contribute!!!

PDS (PDSway@aol.com)
05/03/2003
