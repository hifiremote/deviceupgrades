Digihome PVR80 [SAT] Sling Remote Bins Version 1.0

ReadMe
======

This ZIP file contains 4 BIN files.  Put them into your C:\Program Files\Sling Media\Slingplayer\SBAV\ folder (For the Mac it is 
/Applications/SlingPlayer/Contents/Slingbox Setup Assistant/Contents/Resources/SBAV/).


Now go into the Slingbox and run the Audio/Visual setup again.  This time use 'Other' as the brand and in the next screen use V2010 in the Alternative Code window (That applies to  Slingplayer V1.5.  If you have V2.0 then the Custom code selection is at the end of the code numbers).  If that is rejected (either immediately you type it in in V1.5 or after you press the Power button in V2.0) then try V2011, V2012 and V2013.  Only one of them will work, depending on which chip is fitted to your Slingbox.

