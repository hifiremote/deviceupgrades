#!/bin/bash

# by Ken Truesdale

# Since this is a shell script, it cannot be given a special run permission 
# like an executable can.  (Well, actually, it can, but it is functionally 
# ignored since the script isn't a program but a parameter passed to the 
# shell command /bin/bash - you could give /bin/bash privileges but that 
# would be a really bad idea.)  Instead, you need to add the following 
# content to the sudoers file by executing sudo visudo (place the lines
# above the include line that is the last line in the file, replace the
# word "user" below with your username):
#
#    # Allow members of group sudo to execute specific commands without a password
#    Cmnd_Alias USER_COMMANDS = /home/user/bin/start-lightdm.sh, /home/user/bin/start-lightdm.sh -x
#    user     ALL=(root) NOPASSWD: USER_COMMANDS
#
# Note that even after the above 3 lines are added, this script will 
# need to be called with "sudo" in the command to get the sudoers file
# to come into play.  And even then, the script will need to be called
# fully qualified to not need the password.  Therefore, when calling
# from another script, be sure to fully qualify the call to this script.
# When using interactively at the command prompt, fully qualifying is
# probably not worth the trouble and you can simply enter your password.


# default to not forcing restart
FORCE_RESTART=0
if [ $# -eq 1 ]
then
    if [ $1 = "-x" ]
    then
        # set force restart on
        FORCE_RESTART=1
    fi
fi

if [[ ($FORCE_RESTART -eq 1 ) && ( ! -z `pidof lightdm`) ]]
then
    # if force restart is on and lightdm is already running, then do the force
    sudo restart lightdm
else
    # either force restart isn't on or lightdm is not already running, 
    # so just start it; if lightdm is already running and this script 
    # is called, the following will simply say it is already running
    # and exit gracefully
    sudo start lightdm
fi

# if lightdm successfully started, then the return code will be zero;
# if it didn't start or restart, then the return code will be something
# other than zero
exit $?
