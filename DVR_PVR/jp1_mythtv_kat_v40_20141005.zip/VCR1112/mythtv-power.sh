#!/bin/bash

# by Ken Truesdale

# script to "turn on" MythTV; that is, make sure window manager is running, 
# make sure Mythfrontend is running, raise Mythfrontend window, and deactivate
# the screensaver

# takes optional "-f" argument to force restarting current frontend
# or optional "-x" argument to force restarting X

FORCE_RESTART_FRONTEND=0
FORCE_RESTART_LIGHTDM=0
if [ $# -eq 1 ]
then
    if [ $1 = "-f" ]
    then
        FORCE_RESTART_FRONTEND=1
    fi
    if [ $1 = "-x" ]
    then
        FORCE_RESTART_LIGHTDM=1
    fi
fi

# try to start lightdm
if [ $FORCE_RESTART_LIGHTDM -eq 1 ]
then
    sudo ~/bin/start-lightdm.sh -x
else
    sudo ~/bin/start-lightdm.sh
fi

# if it was already running, we'll get an error result; otherwise, no error, so exit here
if [ $? -eq 0 ]
then
    # lightdm was not already started so we've kicked things off now
    # no need to continue since starting lightdm should take care of the rest below
    exit 0
fi
# we know the window manager was already running so we can continue


# if forcing restart, first kill current session
if [[ ( $FORCE_RESTART_FRONTEND -eq 1 ) && ( ! -z `pidof mythfrontend.real` ) ]]
then
    killall mythfrontend.real

    TRIES=0
    echo "waiting for mythfrontend.real to die..."
    while [[ ( $TRIES -lt 30 ) && ( ! -z `pidof mythfrontend.real` ) ]]
    do
        TRIES=`expr $TRIES + 1`
        sleep 1
    done

    if [ -z `pidof mythfrontend.real` ]
    then
        echo "mythfrontend.real successfully killed"
        sleep 1
    else
        echo "gave up waiting for mythfrontend.real to die"
    fi
fi


# if Mythfrontend isn't already running, start it now
if [ -z `pidof mythfrontend.real` ]
then
    DISPLAY=:0 /usr/bin/mythfrontend --service &

    (for i in $( seq 1 30 )
    do
        echo $i;
        sleep 0.1;
    done) | DISPLAY=:0 zenity --auto-close --progress --text="Starting MythTV..." --title="Starting MythTV..."
fi

# tell MythTV frontend to go to the main menu
echo "jump mainmenu" | netcat localhost 6546

# raise MythTV frontend window
DISPLAY=:0 wmctrl -a "MythTV Frontend"

# deactivate screensaver - if not active, resets idle timer
DISPLAY=:0 xscreensaver-command -deactivate

exit 0
