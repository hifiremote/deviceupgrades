Device Upgrade for Mythtv and LIRC
==================================
Ken Truesdale, 17-Oct-2011, updated 5-Oct-2014
Based on the work of Indulis Bernsteins (11-October-2006)
and Marko Friedemann, Tom Bongiorno, and others


Overview
========
JP1 remotes are great for being able to program and MythTV is equally 
flexible.  Therefore, you can sort of make up your own codes and set them 
up on each device.  Interestingly, however, I didn't have much luck with the
original codes from Indulis.  For whatever reason, the protocol seemed dodgy 
on the serial connection and wouldn't work at all with an Xbox IR receiver.  
So the original work from Indulis has been largely replaced now with newer 
setups from Marko, Tom, and others.  

I recommend you start with the newer option which is the one compatible with 
Xbox IR receivers.  The files for that are in the folder named DVD1112 and if
it works for you, ignore the folder named VCR1444.  However, if you can't get
the files in DVD1112 to work for you, consider the files in VCR1444 a backup
or an alternate.  

(If you have an Xbox or an RCA DVD player, you may want to consider the 
alternate since the codes in DVD1112 are based on those codes and could 
inadvertently control the wrong device.)  

I have three different remotes that I use for MythTV so I included device 
files oriented for each of the three.  And all three files are setup for both
DVD1112 and VCR1444.  Of course, if you have a remote other than these three, 
you can use Keymap Master or Remote Master to adapt what I have here for your 
needs.  

For anyone interested in how I got to this point or for anyone who needs 
information on doing this setup for another remote, see 
http://blog.katharsys.com/?s=mythtv+remote and click on the appropriate links
in that post for more detailed discussion on the debugging and setup process.


Manifest
========
./README_mythtv_jp1_kat.txt                   - this file
./VRC1112/hardware.conf                       - the LIRCd hardware configuration file
./VRC1112/lircd.conf                          - the LIRCd configuration file
./VRC1112/lircrc                              - the resource file for LIRC to be renamed .lircrc
./VRC1112/mythtv-power.sh                     - script for restarting MythTV to be called from .lircrc
./VCR1112/start-lightdm.sh                    - script for use with mythtv-power.sh
./VRC1112/Comcast1067_MythTV-VCR1112.rmdu     - the Remote Master device upgrade file for a Comcast1067 remote
./VRC1112/Comcast1067_MythTV-VCR1112_KM.txt   - the Keymap-Master device upgrade file for a Comcast1067 remote
./VRC1112/ReplayTV5000_MythTV-VCR1112.rmdu    - the main Remote Master device upgrade file for a ReplayTV5000 remote
./VRC1112/ReplayTV5000_MythTV-VCR1113.rmdu    - the extra Remote Master device upgrade file for a ReplayTV5000 remote
./VRC1112/ReplayTV5000_MythTV-VCR1112_KM.txt  - the Keymap-Master device upgrade file for a ReplayTV5000 remote - old version, avoid using, see note below
./VRC1112/URC-881x_MythTV-VCR1112.rmdu        - the Remote Master device upgrade file for a URC-881x
./VRC1112/URC-881x_MythTV-VCR1112_KM.txt      - the Keymap-Master device upgrade file for a URC-881x
./VRC1444/hardware.conf                       - the LIRCd hardware configuration file (reference only)
./VRC1444/lircd.conf                          - the LIRCd configuration file
./VCR1444/lircrc                              - the resource file for LIRC to be renamed .lircrc
./VCR1444/Comcast1067_MythTV-VCR1444.rmdu     - the Remote Master device upgrade file for a Comcast1067 remote
./VCR1444/Comcast1067_MythTV-VCR1444_KM.txt   - the Keymap-Master device upgrade file for a Comcast1067 remote
./VCR1444/ReplayTV5000_MythTV-VCR1444.rmdu    - the Remote Master device upgrade file for a ReplayTV5000 remote
./VCR1444/ReplayTV5000_MythTV-VCR1444_KM.txt  - the Keymap-Master device upgrade file for a ReplayTV5000 remote
./VCR1444/URC-881x_MythTV-VCR1444.rmdu        - the Remote Master device upgrade file for a URC-881x
./VCR1444/URC-881x_MythTV-VCR1444_KM.txt      - the Keymap-Master device upgrade file for a URC-881x
                    

Set up your remote control
==========================
If using Keymap-Master, open Keymap-Master in Excel and load the Keymap-Master file that most closely 
matches your remote.  

**** Note that only the rmdu files are most up to date for the ReplayTV5000 remote since the extender isn't
in KeymapMaster.  The date stamps should help you see what has been updated recently and what has not.  ****

If you are using a different remote from any of the three remote types I've set up, load the 
URC-881x_MythTV-VCR1112_KM.txt file as a starting point then change the Remote cell in the 1st 
worksheet in the Keymap-Master workbook to match your remote control's model number, and go to 
the Buttons page to do your function to button mapping.  Once you've finished modifying the buttons 
sheet, go into IR, attach your remote control via a JP1 cable and download your remote control into 
IR and save this to a file (or load your previously saved file that is already uploaded in your 
remote).  Go back to Kepmap-Master to the Setup page and Copy/Paste the device upgrade into IR, assign 
VCR-1112 to a device key (e.g. VCR), then upload to your remote.  Save what you've done to a new file 
name.


If using Remote Master only, open Remote Master and either load an existing configuration or 
download the contents of your remote and save.  Edit a device and load the appropriate rmdu file to 
define that device.  Save the configuration as a new file.  Then upload to your remote.  

There are two rmdu files for ReplayTV remote because the remote doesn't allow key moves but there 
was more that I wanted to do than could be done within the single 1112 device.  So the 1113 device
is a stub device just for the extras.  Load this in as a new device and assign it to AUX3.  Then
each function in 1113 can be called from via a macro.  Here is my list of macros for the ReplayTV
remote.  Although you can't simply import them (which would be nice), you can at least see how to
set up your own macros.  The macros that don't end with X_Cancel are done that way so the last 
command in the macro will be repeated (other than the first three macros).  

#	Target Key		Macro Keys					Note
1	TV			X_TV;Power;X_Cancel;V_TV;O_VCR			Toggle power on TV, ready for MythTV
2	Replay			X_TV;CH+;X_VCR;Mute;X_Cancel;V_TV;O_VCR		Ready for MythTV
3	SHIFT-Replay		X_TV;CH+;X_AUX3;Mute;X_Cancel;V_TV;O_VCR	Hard Power
4	SHIFT-Select		X_AUX3;Select;X_Cancel				Browse
5	SHIFT-Jump		X_AUX3;Jump					Next Favorite
6	SHIFT-Enter		X_AUX3;Enter;X_Cancel				Toggle Favorite
7	SHIFT-Left_Arrow	X_AUX3;Left_Arrow				Day Previous
8	SHIFT-Right_Arrow	X_AUX3;Right_Arrow				Day Next
9	SHIFT-Display		X_AUX3;Display;X_Cancel				Toggle Picture-in-Picture
10	SHIFT-Comm_Adv		X_AUX3;Comm_Adv;X_Cancel			Next Active PxP
11	SHIFT-LiveTV		X_AUX3;LiveTV;X_Cancel				Swap PxP Window
12	SHIFT-Stop		X_AUX3;Stop;X_Cancel				Toggle Picture-by-Picture
13	SHIFT-Exit		X_AUX3;Exit;X_Cancel				Toggle Sleep


VCR1112 for Xbox IR receiver (skip to step 6 below if not using Xbox IR receiver)
============================

 1) Blacklist xpad to make sure it doesn't intefere with the IR receiver
        sudo cat >> /etc/modprobe.d/blacklist.conf <<-EOF
            blacklist xpad
            EOF

 2) Install and configure LIRC:
        sudo apt-get install lirc dialog
   
    If you don't yet have LIRC, it will install and then run the configure
    script.  If you already had LIRC, nothing will happen and you'll need
    to kick off the configuration manually:
        sudo dpkg-reconfigure lirc
   
    In the configuration, select "none" for the receiver and the transmitter.

 3) Install lirc source modules:
        sudo apt-get install lirc-modules-source

 4) Modify lirc_dev module:
        sudo nano /usr/src/lirc-0.8.7/drivers/lirc_dev/lirc_dev.h

    The package install in step 3 will automatically compile the source 
    modules but there is a kernel incompatibility that needs to be fixed.
    Change the line "#define LIRC_HAVE_KFIFO" to "#undef LIRC_HAVE_KFIFO"
    (it's probably about line 19 in the source file).  Save and exit.
    
    Now, recompile the files to incorporate the change:
        sudo dpkg-reconfigure lirc-modules-source

 5) Configure the LIRC modules to load at startup
        sudo cat >> /etc/modules <<-EOF
            # load lirc_dev and lirc_atiusb at startup for IR receiver
            lirc_dev
            lirc_atiusb
            EOF


Steps for VCR1112 regardless of IR receiver
===========================================

 6) Replace the hardware.conf that was created during configure with the
    one included here
        sudo cp VCR1112/hardware.conf /etc/lirc/hardware.conf

 7) Replace the lircd.conf that was created during configure with the one
    included here
        sudo cp VCR1112/lircd.conf /etc/lirc/lircd.conf

 8) Copy the lircrc file to ~/.lircrc (note that the file in the zip is missing 
    the leading dot and this copy command adds it in)
        cp VCR1112/lircrc ~/.lircrc

 9) If you want to enable the mythtv-power.sh script, copy it into your .mythtv directory
        cp VCR1112/mythtv-power.sh ~/.mythtv/
    And copy the companion script into your bin directory
        cp VCR1112/start-lightdm.sh ~/bin/
    And then follow the instructions in the header comments of the start-lightdm.sh file
    to get it to work as root without needing a password

10) Reboot or restart LIRC daemon
        sudo service lirc restart
        
11) In terminal window, test out remote commands using irw
        irw
    
    You should see commands appearing as you press buttons.  Make sure MythTV 
    frontend is not running while you are testing or your button presses may 
    cause mischief.  Use Ctrl-C when finished testing.  
 

Set up MythTV
=============

Go into the Utlities/Setup menu of the Frontend and select Setup then General.  Hit next until you get 
to the Remote Control section.  Make sure there is a value in the "LIRC Daemon Socket" field.  Mine is set 
to "/var/run/lirc/lircd" but yours may vary.  

Next, back to the Utlitiles/Setup menu of the Frontend, and select Edit Keys.  In the left column select 
TV Frontend.  Look for the actions below and change them from their original value below by changing as
instructed below.  

 context                      action    original    change
-----------    ---------------------    ---------   ----------------------
TV Frontend                 JUMPFFWD    PgDown      change to Down
TV Frontend                 JUMPRWDN    PgUp        change to Up
TV Frontend                 SEEKFFWD    Right       change to PgDown
TV Frontend                 SEEKRWND    Left        change to PgUp
TV Frontend             SKIPCOMMBACK    Q & Home    add Left
TV Frontend           SKIPCOMMERCIAL    Z & End     add Right
TV Frontend              CHANNELDOWN    Down        change to - (minus)
TV Frontend                CHANNELUP    Up          change to + (plus)
TV Frontend                NEXTAUDIO    +           unset
TV Frontend                PREVAUDIO    -           unset
JumpPoints          Live TV In Guide    N/A         add Shift+F7
JumpPoints     TV Recording Playback    N/A         add Ctrl+R
      
(note that you'll trip over a bug if you try to enter the plus sign through key capture in the frontend
by pressing shift-= since it will result in shift++ and there is no such thing; better to use a keyboard
with a number pad to get the real + without a shift or you can do what I did and just adjust the setting
via SQL.)  

That should get it all working!  Good luck!  