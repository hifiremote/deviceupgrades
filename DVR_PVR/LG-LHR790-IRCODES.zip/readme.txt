These instructions are based on the Version 2 SlingPlayer software for Windows.

To make your Slingbox work with the LRH-790 (a.k.a RH200) and probably other LG DVRs:


1)  Install the SlingPlayer software  

http://downloads.slingmedia.com/go/slingbox-desktop-us

... or the appropriate version for your country.


2)  Figure out which IR Blaster chip you've got.
 a) Open up the Slingbox Properties dialog
    Either press ALT-E or select Help -> About My Slingbox
 b) Select Information
 c) Wait for the dialog box to get populated with data
 d) Find the IR Blaster line

1=JU
2=PL
3=PK
4=RV
5=PL (Slingbox Pro-HD)


3)  Find the update file that matches the IR Blaster in your Slingbox

JU = V0987_JU.bin
PL = V0987_PL.bin
PK = V0987_PK.bin
RV = V0987_RV.bin

(I only tested the PL version)


4)  Copy just the file you need (leaving the filename as-is!) into your SlingPlayer's SBAV directory.

Mine is located at C:\Program Files\Sling Media\SlingPlayer\SBAV


5)  Get the Sling Player to download the IR codes to the Slingbox
 a) Select Settings -> Setup Assistant
 b) Select Configure Video Sources
 c) Pick the input that the LG DVR is connected to
 d) Select Next
 e) Select Standalone DVR
 f) Select Next
 g) Select LG
 h) Select Other
 i) Select Next
 j) Select Custom
 k) Enter the custom code    V0987
 l) Click the Test Remote  Power on-screen push button
 m) Make sure the DVR turns on or off
    If it doesn't react, try a different V0987 file.
 n) Select Next


6) Profit!  :-)



Other notes:

If you want to modify the IR codes, a quick How-To I used on how to build the LG LRH-790 PVR.rmdu source file can be found at:
http://www.slingcommunity.com/article/11832/How-To-Create-Your-Own-SlingPlayer-Remote/


You can also use IR and RemoteMaster (linked to on the above page) to alter the key assignments I picked, send the IR codes to other UEI remotes, and adapt them to other IR remote systems.


If you want to modify the skin for the SlingPlayer, you can try following the tips at:
http://www.slingcommunity.com/forum/thread/17350/Creating-Skins/

... otherwise you'll have to use the SlingPlayer's Remote Menu button to get at the non-standard buttons.




Lots more info on IR, JP1, etc. can be found at:

http://www.hifi-remote.com/ofa/
http://www.hifi-remote.com/jp1/index.shtml
http://controlremote.sourceforge.net/


Have fun!
