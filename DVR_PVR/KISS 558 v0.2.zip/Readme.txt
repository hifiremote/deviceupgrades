KISS VR & DP 558

KISS558_v2.rmdu		Upgrade file
V0999_PL.bin		NTSC version of Slingbox IR file (Serial numbers starting with 507 or higher are PL boxes)
V0999_RV.bin		PAL version of Slingbox IR file (RV chipset)

For differences between PAL & NTSC version of Slingbox & use of BIN files, go to => http://www.slingcommunity.com/

Good luck, Folkert