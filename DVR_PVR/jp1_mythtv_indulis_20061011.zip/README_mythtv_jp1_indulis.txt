Device Upgrade for Mythtv and LIRC
==================================
indulis bernsteins
indulis
  21Cmail
    com
11 October 2006

Changes
- 11 Oct 2006, replaced lircd.conf with a more accurate one based on NEC5 protocol specs.


There are 2 working remote control configurations here,
one is for the One-for-all URC-7560 (black mark I), and the other is for the URC-8811
and family.  You probably won't use the complete configurations (.ir files), you'll just use the
device upgrade (.txt files).

These instructions are for Windows (sorry!) but should translate pretty easily to RemoteMaster
and IR running under Linux.  Once I get some spare time I'll try JP1 under Linux and document it here.

I have created a new device VCR-1444 specifically for mythtv.  The EFC codes are sequentially
assigned, and map to the code definitions in LIRC's configuration file.

Device VCR-1444 has remote codes defined, to match the
linux LIRC files (/etc/lircd.conf and ~/.mythtv/lircrc and ~/.lircrc which are also included here).

To get your remotes working with mythtv:

Set up your remote control
==========================
Open Keymap-master and load either urc8811_indulis_mythtv_VCR_1444_20060713_r.txt
 or urc7560_indulis_mythtv_VCR_1444_20060713_r.txt

These files contain the VCR-1444 device upgrade.

If you are using a different remote from a URC-7560 or URC-8811 (or similar), 
Load the urc8811_indulis_mythtv_VCR_1444_20060713_r.txt file as a starting point, as it has more buttons
defined. Change the Remote cell in the 1st worksheet to match your remote control's model number, 
and go to the Buttons page to do your
function to button mapping.  Once you've finished modifying the buttons sheet, go into IR, 
attache your remote control via a JP1 cable and download your
remote control into IR.  Go back to Kepmap-master to the Setup page and Copy/Paste the device
upgrade into IR, assign VCR-1444 to a device key (e.g. VCR), then upload to your remote.  Save
what you've done to a new file name.

Set up your Linux system
========================
Note- ~ is the shorthand for /home/my_user_name where my_user_name is the login name for each user.
      In the examples below I am using a username of indulis so ~/.mythtv is actually
      /home/indulis/.mythtv
      Change indulis to mythtv or whatever linux user name will be running mythtv

1) extract the files using unzip under linux, or your choice of zip
   utilities under windows
      unzip mythtv_jp1_indulis_20060713.zip

2) Copy the lircrc_mythtv file to ~/.mythtv/lircrc
      cp lircrc_mythtv /home/indulis/.mythtv/lircrc
   NOTE THAT THERE IS NO LEADING "." FOR THIS FILENAME
   Make sure that this is the home directory of the user that will be running mythtv.
   If you have multiple users who will run mythtv you must put a copy into each user's ~/.mythtv directory

5) Copy the lircrc_xine file to ~/.lircrc
      cp lircrc_xine /home/indulis/.lircrc
   This contains a set of mappings for Xine, that mostly match mythtv's mappings
   If you have multiple users who will run mythtv you must put a copy into each user's ~/ directory

6) Copy the mythtv_xine_keymap file to ~/mythtv_xine_keymap
      cp mythtv_xine_keymap ~/mythtv_xine_keymap

7) modify your mythtv Setup-Media Settings-DVD-Play settings if you are using xine to be
   xterm -geometry 1x1-0-0 -e xine -pfhq --no-splash --keymap=file:/home/indulis/mythtv_xine_keymap dvd://

8) Copy the lircd.conf file to /etc/lircd.conf

9) Restart the lircd daemon.  On Ubuntu this is
     sudo /etc/init.d/lircd restart
   If you don't know the command you can just reboot

10) Run irw to check the remote is working- you should get commands appearing as you press buttons.
   Make sure that mythtv is not running or your button presses may delete programs or cause other mischief.

Using the complete remote control ".ir" configurations
=====================================================

First, you will probably find they are not directly applicable to you,
but could serve as an example of how to use the extenders, macros,
and other functions.

There are two .ir files, one for the URC-8810, which has just the VCR-1444
device I created for mythtv.  The other is a very full-featured complete
remote control with macros etc for the URC-7560.

For the URC-7560, an extender is being used to allow Magic-device keys to work (e.g. Magic-DVD
becomes a programmable key).
To enable the extender after uploading to the remote, here is the process.

DO NOT DO THIS FOR THE URC-8811 (well it wont hurt but you don't need to!).

1) Wait for 1 flash
2) Press the 10 and AV buttons at the same time
3) Wait for 2 flashes
4) Press the 0 button
5) You should see 4 flashes which shows that the extender is working

