dlevin31262@newsfeeds.com

================================

I believe these files will work fine with the 721 as well.

================================

The device combiner spreadsheed originally came from w_jackson & unclemiltie.

I needed to mod it for the 6131 key assignments, and to get the PIP keys working.

921 (& 721) use two sub-device codes (different then unit/remote codes)

The special "Device Combiner" protocol allows for combining multiple devices and/or procotals as a single device.  Note that the "Fixed Data" is set up for the 6131.  Different remotes may require a modification to the fixed data.

The majority of the keys come from the main spreadsheet.  Problem is that the PIP keys are not assignable under the SAT/VCR/PVR modes.  So, they must be keymoved in from a second device upload.

Important Keymove note:  The 6131 does keymoves differently then the other URC remotes.  Key move from Keymapmaster/IR don't work unless a special (and complicated) extender it used.  Therefore the 3 pip keys are programmed on the remote directly after the upload is performed.

If you don't need the PIP keys, or don't mind mapping them to different keys, they can be assigned in the combiner spreadsheet and the device 1 spreadsheet and key moves are note needed.

921_6131_Dev_1.txt is a TV device containing only the PIP keys.

So:
Connect the remote, run ir, and upload the current configuration.  If you haven't already, save this away somewhere.

Customize the combiner spreadsheet as desired (key locatons and remote/unit code).  SEE THE COMMENT BOX FOR INSTRUCTIONS ON HOW TO CHANGE THE UNIT CODE).  Then load the 1775 PVR device and special device combiner protocol into ir (the PVR device will turn into a VCR device).  Go to the general tab and assign the 1775 VCR device to a device button.

Load 921_6131_Dev_1.txt into keymapmaster, change the unit code if necessary (if using a remote code other then 1), and paste this device into ir.  Go to the General tab and assign TV 1775 to a device button (this is temporary - you can reassign the button after the keymove is done).

Download from ir to the remote.

On the remote, keymove the three pip keys from the TV-1775 device to the PVR/VCR-1775 device.  Once this is done the device button containint TV-1775 can be reassigned to a different device.

================================

Here's the keymove instructions from 6131 manual:

USING KEYMOVER
The One For All 6-Device PVR Universal Remote
Control includes a Keymover feature that allows you to
map (or copy) keys from one mode (i.e., source mode)
to another mode (i.e., destination mode).

NOTE: The following keys cannot be used as a source or
destination: TV, PVR, DVD, CBL/SAT, AUD, VCR, and SET.


Programming Keymover (DL - Modified for PIP from TV 1000)

For example, if your VCR does not have volume control,
you can map those keys (i.e., VOL+, VOL-, and Mute)
from the TV mode to the VCR mode as follows:

1. Press and hold SET until the LED (red light)
blinks twice, then release SET.

2. Enter 9 - 9 - 4.  The LED will blink twice.

3. For the source mode, press TV once.

4. For the source key, press PIP once.

5. For the destination mode, press PVR (or SAT if it's there) once.

6. For the destination key, press PIP once.

7. The LED will blink twice indicating the
keymoved sequence is correct.

8. Repeat steps 1 through 7 twice more to
map PIP Swap and PIP Move.

Restoring Keymoved Keys to Default Settings
Restoring A Single Keymoved Key
1. Press a device key that has a keymoved key.
2. Press and hold SET until the LED (red light)
blinks twice, then release SET.
3. Enter 9 - 9 - 4.The LED will blink twice.
4. Press the destination key twice (where the
keymoved key is stored).The LED will
blink twice.


========================================
dlevin31262@newsfeeds.com
