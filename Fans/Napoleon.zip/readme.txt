This upgrade is for a
NEFL42SB-LOWC Wall Mount Electric Fireplace.
Taken with an RCA RCRP05B learning remote.

There are only 5 buttons.
Power, Heat, Timer, Flame Up, Flame Down