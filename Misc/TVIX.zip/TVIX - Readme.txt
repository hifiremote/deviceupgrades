The TVIX-Delayed Repeat file AKA the "Friday Special" is an upgrade that was created to meet the needs of the user in this Thread.
http://www.hifi-remote.com/forums/viewtopic.php?t=10196&highlight=

Better solutions that involve extenders or shift keys could be crafted, but they were not an option in this case.

Keys do not repeat until the button has been held down for about a second.

Includes PB files, and RMDU files for both protocols and rawtimings from learned codes.  