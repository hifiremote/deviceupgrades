ReadMe for Lexicon DC-1 v3 & v4.txt
Kent Sullivan
kentsu@corvairkid.com
7 July 2002

The accompanying KeyMaster text file dump contains the complete list of codes sent by the Lexicon DC-1 v4 remote control, as charted by me. (Translation: I may have screwed something up!)

I believe that the DC-1 v3 uses a subset of these codes, so this set of codes should apply. Also, it is my understanding that the DC-2 uses the same remote control so the same codes likely also apply to it. Someone will need to try it and tell me...

For my personal setup, I use the following Advanced Code mappings (Key Moves via the IR program) to enhance the basic programming done by the KeyMaster output:

1S			Dolby Effect
2S			THX Effect
3S			Logic 7 Effect
4S			DTS Effect
SHIFT-POWER		Power Off
SHIFT-MUTE		Full Mute
SHIFT-ARROW_LEFT	Balance Left
SHIFT-ARROW_RIGHT	Balance Right
SHIFT-ARROW_UP		Fade Front
SHIFT-ARROW_DOWN	Fade Rear
SHIFT-VOL+		Bass +
SHIFT-VOL-		Bass -
SHIFT-CH+		Treble +
SHIFT-CH-		Treble -

I also program the 1S button for each of my other devices to select the corresponding input on the Lexicon. For example, pressing 1S when in VCR mode sends the "VCR Input" code to the Lexicon.

Enjoy,

--Kent