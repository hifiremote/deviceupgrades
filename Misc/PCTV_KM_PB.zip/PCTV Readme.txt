The PCTV upgrade includes a protocol upgrade as well as the single keypress values for the 41 key (grey w Blue buttons) PCTV remote.  The KM was created with a RS 15-2116 remote but can be mapped to other JP1 remotes.

Notes on the keymap:
The Power, Numbers, Transport controls, Arrows/Select/Menu, Vol, Mute, Channel +/-/Last have standard mappings to the buttons on the RS remote.

The other keys are mapped as:

PCTV Remote Button	RS 15-2116 Button	Hex Code
-------------------	-----------------	--------
FullScreen		PIP			85 52
Zoom			Info/Display (keymove)	B2 61
Replay/Skip Back	TV/Video		0A 65
Skip Forward		Sleep (keymove)		E6 4D
TV			PIP move		78 66
Teletext		PIP freeze		E2 5A
Radio			(not mapped)		A7 6A
EPG			Guide			1B 79
Goto End (>| btn)	Exit			90 59
Circle P		Swap			C0 62
Circle L		(not mapped)		39 41
Circle I		(not mapped)		2C 4A

How to use:
Load the PCTV KM file into the KM spreadsheet.
Change the remote, device type and setup code as necessary.
Go to the functions tab & map the hex values to the buttons on your remote.
Copy the protocol code into the protocol tab of IR.exe.
Copy the device upgrade into the device tab of IR.exe.
Upload to your remote.

*** NOTES ***
-The PCTV remote sends different codes for single keypresses and repeat keypresses.  This keymap only handles the single keypress codes... the remote will repeat the single keypress code but it will not send the special repeat code that the PCTV remote does.

-The PB file is already loaded into the PCTV KM file.  It is only provided if you want to modify the PCTV protocol... for example changing the frequency of the repeats.