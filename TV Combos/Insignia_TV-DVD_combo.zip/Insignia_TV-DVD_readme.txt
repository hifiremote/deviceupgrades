I created two versions of the protocol used by this Insignia TV/DVD unit because the unit uses different device codes for the TV and DVD functions.

The first version of the protocol uses just one device code, so you would need seperate upgrades for the TV and DVD functions.  The files with "side" in the title use this protocol.

The second version is a combo protocol that lets you combine as many different device codes as you need.  The 3rd upgrade uses this protocol and it contains all of the buttons for this unit.

Rob
rob1@rockabilly.net