The only files that you need are Airboard_Combination_KM.txt and Airboard_Mouse_KM.txt.  The Airboard Combination is every possible key and variation for the keyboard. The Mouse commands are different and need to be key moved to the device where the other Airboard commands are located, presumably to the arrow keys.


Airboard_Combination_KM.txt

The Airboard keyboard like most keyboards has a make and break command for each key. Make is when the key is depressed, break when released. Each key can also send several other commands.  There is a universal hold command that I have labeled  **53** and is the same for all keys and starts after the make command if that key is held down. That way you get repeating key behavior. Then the Break command (one bit changes from the make command) and a universal clear command **5D**.  It�s probably a good idea to load the upgrade into KM and open the Functions tab to follow the discussion here.

If you have no need for compound key sequences like ctrl-alt-del, then you needn't worry about how the commands work, since the protocol sends all those keys for you, like the keyboard.  If you do need the compound key sequences then you will need to generate each command separately.

The protocol has a control byte (byte 2) that changes what commands it sends, If Byte2=0, then it sends then make, break, and all clear command.  They do not repeat when held. This executes very fast and will probably be the one used for most keys. If Byte2=1, then the key will repeat for things like arrow keys, page-Up, etc. If Byte2=2 then it will send only a make OR break command depending on what OBC you assign.  Bytte2=2 will be how you can create compound keys , since ctrl-alt-del is really:

ctrl (make) - Alt (make) - Del(make) and theoretically would be followed by:
ctrl (break) - Alt (break) - Del(break)

But in practice you rarely need the second part.  You must use a macro to create the compound keys and if you need very many then you probably want to look into Device Specific Macros (DSM) that is included in most of the extenders and special protocols.


You will need to install the two device upgrades and protocol upgrades.  Both protocols have two variable bytes and you can only key move them in IR.  Slect hex rather than EFC, then enter both bytes with a one space in between.

Async_Protocol.1PB.txt is the protocol Builder file and is for an advanced user who wants to change how the protocol works with the assembly language feature of Protocol Builder 3.11.