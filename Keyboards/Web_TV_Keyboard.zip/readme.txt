WebTV Keyboard is a device/protocol created by Jon Armstrong
with assistance from John Fine to allow your remote to send
the IR signals which a WebTV keyboard would normally generate.
It was partially based on a pronto ccf file.

In the process of adapting his work for text/symbol entry into
ReplayTV, I've taken his original work and slightly cleaned up
the KM file and added arrow key support.

I have tested every key which has a ReplayTV mapping but cannot
comment on the other unmapped keys as I do not have a device
which understands the full WebTV keyboard set.

There are 2 files:
Web_TV_Keyboard-KM.txt
Web_TV_Keyboard_for_Replay-KM.txt

The first is a cleaned up version of Jon's original work.
The second is a sample ReplayTV mapping for a 15-2117 remote.

To use, simply load the appropriate file into KM, cut/paste
the device *and* protocol into IR, define a device to use
cbl/1985, upload to your remote, and start experimenting.

Optionally, you can adjust the remote control model and
button mappings in KM.

CAVEATS:
1) ReplayTV ignores symbols in searches, so if you wanted to
create a Theme for:

CSI "CSI Crime" would find "CSI: Crime Scene Investigation"
MI5 "MI5"       would find "MI-5"

Thus it is not necessary to enter symbols into the title of
a show (thus you might not want to go through the trouble of
using this device/protocol for ReplayTV other than for aesthetics)

2) To enter the shifted version of any key, use the CAPS key
(mapped to Enter in the 15-2117 sample KM file)  This functions
as a shift-lock, so you need to press it again when you are
finished entering the shifted version of keys.

3) Some keys do not appear to display the proper character in
ReplayTV, in particular:

~ tilde        (shift-grave) displays   ` grave
) right-paren  (shift-zero)  displays   0 zero
" double-quote (shift-quote) displays   , comma
' quote        (quote)       displays   , comma

4) ReplayTV has it's own idea about how to capitalize letters.
The WebTV keyboard doesn't overide the builtin algorithm.

-
- sfhub (PM me at http://www.avsforum.com/)
-

----

If you are interested in the details, read on...

At this point it may be useful to discuss some keyboard basics
with a blurb from Jon Armstrong:

It may be useful to cover how keyboards work. Each key has two
commands down and up. There is probably a held command and an
all clear that are the same for all keys, but I don't think
they are important for what you want. There is only one "a" key.
"A" is shift-"a" to do a shift anything; the command sequence
is shift-down, a-down, a-up, and shift-up for a total of 4
keystrokes. ctrl-alt-delete would be ctrl-down, alt-down,
del-down, del up, alt-up and ctrl-up. Since the device being
controlled generally executes when del-down is sent, the rest
of the commands are moot. 

On the "Functions" page of KM you'll notice the OBCs defined
are all for "key-down".  The matching "key-up" OBCs are listed
in the Description/Notes column.  To properly emulate a WebTV
keyboard you'll need to define a macro for each key with the
"key-down" followed by the "key-up"

However in my testing with *ReplayTV* I've found that in many
cases you really only need to use the OBC for "key-down" as
long as you don't press the same key twice.

For example when I try to enter "gg" what is being sent to
ReplayTV is g(down) g(down), which doesn't make much sense
as there should have been an g(up) sandwiched in between and
at the end of the sequence, if this had been a real keyboard.

There seems to be a feature of the ReplayTV keyboard processing
(possibly others) which will interpret two different "key-down"
presses as if there was a "key-up" in between.

For example:
g(down) h(down) g(down) h(down) 

is interpreted as:
g(down) [g(up)] h(down) [h(up)] g(down) [g(up)] h(down)

You can take advantage of this fact to enter repeating characters.
In the above example of entering "gg", we could have entered the
following to accomplish what we wanted (using only key-down OBCs)
g(down) arrow-up(down) g(down)

Regarding the OBCs, in my ReplayTV testing I have found there are
two ways to define any particular key.  The last nibble (4 bits)
of any particular OBC will either be 0, 2, 8, A.  In particular
0 and 2 are paired as are 8 and A.  They can be used interchangeably.

For example:
'a' OBC 52 E0  or  OBC 52 E2
'h' OBC 56 78  or  OBC 56 7A

Finally, I'm providing the mappings from the WebTV key to the ReplayTV
equivalent function.  This would be useful in defining your own button
maps.
[code]
sorted by function
                     ALT
WebTV Key      OBC   OBC   ReplayTV Key
ESC           54 50 54 52  EXIT
F1            50 C0 50 C2  MENU
F2            50 A0 50 A2  DISPLAY
F3            54 20 54 22  ZONES
F4            56 20 56 22  COMMERCIAL ADV
F5            56 40 56 42  no equivalent
F6            56 70 56 72  INSTANT REPLAY
F7            54 18 54 1A  QUICK SKIP

FAVS          50 98 50 9A  REPLAY GUIDE
HOME          50 F0 50 F2  CHANNEL GUIDE

UP?           56 48 56 4A  UP
DOWN?         50 28 50 2A  DOWN
LEFT?         50 48 50 4A  LEFT
RIGHT?        50 68 50 6A  RIGHT

EDIT          50 C8 58 CA  no equivalent
INFO          52 28 52 2A  no equivalent
SEND          52 48 52 4A  no equivalent
MAIL          54 A8 54 AA  no equivalent
GOTO          54 D0 54 D2  no equivalent
FIND          54 E8 54 EA  no equivalent
SEARCH        54 F0 54 F2  no equivalent
SAVE          56 D0 56 D2  no equivalent

` (grave)     50 80 50 82  `
1             54 E0 54 E8  1
2             54 C0 54 C2  2
3             54 A0 54 A2  3
4             54 90 54 92  4
5             50 90 50 92  5
6             50 F8 50 FA  6
7             54 F8 54 FA  7
8             54 B8 54 BA  8
9             54 98 54 9A  9
0             54 D8 54 DA  0
- (minus)     50 D8 50 DA  -
= (equal)     50 B8 50 BA  =
DEL           54 70 54 72  BACKSPACE

TAB           54 60 54 62  TAB SYMBOL (rectangle)
q             56 E0 56 E2  q
w             56 C0 56 C2  w
e             56 A0 56 A2  e
r             56 90 56 92  r
t             54 10 54 12  t
y             54 78 54 7A  y
u             56 F8 56 FA  u
i             56 B8 56 BA  i
o             56 98 56 9A  o
p             56 D8 56 DA  p
[ (l-bracket) 54 58 54 5A  [
] (r-bracket) 54 38 54 3A  ]
\ (b-slash)   52 F0 52 F2  \

CAPS          54 40 54 42  SHIFT LOCK
a             52 E0 52 E2  a
s             52 C0 52 C2  s
d             52 A0 52 A2  d
f             52 90 52 92  f
g             56 10 56 12  g
h             56 78 56 7A  h
j             52 F8 52 FA  j
k             52 B8 52 BA  k
l             52 98 52 9A  l
; (s-colon)   52 D8 52 DA  ;
' (quote)     56 58 56 5A  ' (display err? comma)
RETURN        52 70 52 72  SELECT

SHIFT         52 30 52 32  no equivalent
z             52 60 52 62  z
x             52 40 52 42  x
c             52 20 52 22  c
v             52 10 52 12  v
b             50 10 50 12  b
n             50 78 50 7A  n
m             52 78 52 7A  m
, (comma)     52 38 52 3A  ,
. (period)    52 18 52 1A  .
/ (slash)     50 58 50 5A  /

SPACE         50 70 50 72  SPACE



sorted by #
                     ALT
WebTV Key      OBC   OBC   ReplayTV Key
b             50 10 50 12  b
DOWN          50 28 50 2A  DOWN
LEFT          50 48 50 4A  LEFT
/ (slash)     50 58 50 5A  /
RIGHT         50 68 50 6A  RIGHT
SPACE         50 70 50 72  SPACE
n             50 78 50 7A  n
` (grave)     50 80 50 82  `
5             50 90 50 92  5
FAVS          50 98 50 9A  REPLAY GUIDE
F2            50 A0 50 A2  DISPLAY
= (equal)     50 B8 50 BA  =
F1            50 C0 50 C2  MENU
EDIT          50 C8 58 CA  no equivalent
- (minus)     50 D8 50 DA  -
HOME          50 F0 50 F2  CHANNEL GUIDE
6             50 F8 50 FA  6

v             52 10 52 12  v
. (period)    52 18 52 1A  .
c             52 20 52 22  c
INFO          52 28 52 2A  no equivalent
SHIFT         52 30 52 32  no equivalent
, (comma)     52 38 52 3A  ,
x             52 40 52 42  x
SEND          52 48 52 4A  no equivalent
z             52 60 52 62  z
RETURN        52 70 52 72  SELECT
m             52 78 52 7A  m
f             52 90 52 92  f
l             52 98 52 9A  l
d             52 A0 52 A2  d
k             52 B8 52 BA  k
s             52 C0 52 C2  s
; (s-colon)   52 D8 52 DA  ;
a             52 E0 52 E2  a
\ (b-slash)   52 F0 52 F2  \
j             52 F8 52 FA  j

t             54 10 54 12  t
F7            54 18 54 1A  QUICK SKIP
F3            54 20 54 22  ZONES
] (r-bracket) 54 38 54 3A  ]
CAPS          54 40 54 42  SHIFT LOCK
ESC           54 50 54 52  EXIT
[ (l-bracket) 54 58 54 5A  [
TAB           54 60 54 62  TAB SYMBOL (rectangle)
DEL           54 70 54 72  BACKSPACE
y             54 78 54 7A  y
4             54 90 54 92  4
9             54 98 54 9A  9
3             54 A0 54 A2  3
MAIL          54 A8 54 AA  no equivalent
8             54 B8 54 BA  8
2             54 C0 54 C2  2
GOTO          54 D0 54 D2  no equivalent
0             54 D8 54 DA  0
1             54 E0 54 E8  1
FIND          54 E8 54 EA  no equivalent
SEARCH        54 F0 54 F2  no equivalent
7             54 F8 54 FA  7

g             56 10 56 12  g
F4            56 20 56 22  COMMERCIAL ADV
F5            56 40 56 42  no equivalent
UP            56 48 56 4A  UP
' (quote)     56 58 56 5A  ' (display err? comma)
F6            56 70 56 72  INSTANT REPLAY
h             56 78 56 7A  h
r             56 90 56 92  r
o             56 98 56 9A  o
e             56 A0 56 A2  e
i             56 B8 56 BA  i
w             56 C0 56 C2  w
SAVE          56 D0 56 D2  no equivalent
p             56 D8 56 DA  p
q             56 E0 56 E2  q
u             56 F8 56 FA  u
[/code]