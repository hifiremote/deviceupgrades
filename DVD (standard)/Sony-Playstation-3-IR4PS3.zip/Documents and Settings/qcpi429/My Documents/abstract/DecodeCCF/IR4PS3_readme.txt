This is a complete configuration for Ben's IR4PS3 infrared 
remote control solution for the Sony PlayStation 3, in 
standard JP1 format. It includes codes for all 53 supported 
functions for all 7 distinct codesets supported by the IR4PS3:

* Sony DVD + PS2
* Sony DVD-R + PS2
* Sony BD + PS2
* Custom Codeset 1
* Custom Codeset 2
* Custom Codeset 3
* Custom Codeset 4

