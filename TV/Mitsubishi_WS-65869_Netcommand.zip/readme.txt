The files included in this zip archive include a new protocol (written by Jon Armstrong) which has the correct timing for the newer Mitsubishi televisions with NetCommand.  The original Mitsubishi protocol (TV/0150) does not work perfectly with these newer televisions -- The typical symptom is that each keypress is seen as two keypresses by the TV.  This can be especially annoying with the arrow keys.

To use these files:
- Load "Mitsubishi_WS-65869_Netcommand.txt" into the latest Keymap-Master spreadsheet
- change the remote model to whatever JP1 remote you use
- run IR.EXE, and "Download from remote" to get you current configuration.  Save a copy in case something goes wrong.
- copy the protocol code from KM, and paste it into IR.EXE as a new protocol
- copy the device Upgrade Code from KM, and paste it into IR.EXE as a new device
- Assign this new device (Video/1150, unless you decided to change it in KM) to a device key
- "Upload to Remote" in IR.EXE


The file: Mitsubishi_NetCommand-frame set to 53.6mS-PB.txt is the Protocol Builder file that Jon Armstrong used to create the protocol upgrade.  You should not need to use this, but it is included in case you want to try and modify it.



Below is selected pieces of the messages discussing this protocol in the JP1 forum:


( the thread is here: http://www.hifi-remote.com/forums/viewtopic.php?t=1449)

--------------------------------------------------------------------------------
johnsfine
 Posted: Mon Feb 16, 2004 9:15 am    Post subject:    

--------------------------------------------------------------------------------
 
You'll notice in those learned signals that the repeat has strange timing. Every other gap between frames is extra long. 

I assume the device expects exactly two frames (at normal speed) for a normal keypress. The original remote delays before the third frame so that the user would need a significantly long keypress to get more than two frames, which the device interprets as wanting to execute the command more than once. 

The UEI remote normally sends more than 2 frames and has the same gap between frames every time. 

Rob and "Mr Cinema 7" and I (and I'm not sure who else) know how to tweak a UEI protocol that way: Normally send exactly two frames for either a typical keypress or use in a macro, and for long keypresses alternate between the normal frame gap and one about a tenth of a second longer than normal. 

I don't have time to do it today (maybe later in the week). I don't know if Jon knows a way to do that tweak or if someone else who knows has time. 
--------------------------------------------------------------------------------
 
jdoss
 Posted: Mon Feb 16, 2004 11:36 am    Post subject:     

--------------------------------------------------------------------------------
 
Jon, 

I have all the discretes working fine; They are all simple single Mitsubishi:71 (TV/0150) codes, found by learning from the remote set to 0-9-0 mode, as you described. I don't know if the TV actually interprets each of the discretes as two key presses or one, but for the discretes, it doesn't matter. 

The keys that do matter (partially) are ones like pause, FF, REW (in order to control the firewire-connected Mits DVHS VCR, the TV has to issue transport commands through firewire). With TV/0150 codes, it sees each key press as two, so "Pause" becomes "Pause, then immediately Un-pause", etc. Other keys like "Guide" and "Info" also toggle on/off with two key presses. 

Even these work fine when I learn them with a single press & release (as opposed to holding down the original button). They do not repeat, but I don't need repeats for Pause, REW, FF, Guide, Info, etc. I would prefer not to take up all the learning memory on the 2116 or 1994, but I can live with it. 

The truly annoying keys are the arrows -- In order to set-up a firewire-based recording, I have to set the start time by scrolling up and down minute-by-minute, through potentially 24-hours (1440 minutes). The TV scrolls the minutes very rapidly when you hold down the up or down arrows on the original remote, and moves one minute at-a-time with single presses of up or down. I have not been able to re-create this behavior on a UEI remote � TV/0150 or learning with the button held down both give me the fast scroll on repeats, but no way to move minute-by-minute, because it sees each single press as two. Learning the arrows with a quick �Press & Release� gives me the minute-by-minute changes, but no repeats, so I have to press the button hundreds of times to reach the desired time. I would be very happy if I just had the up and down arrows working as they do on the original remote, in Netcommand mode. 

This is a 2001 model Mitsubishi WS-65869, one of the first with NetCommand/firewire and an integrated HDTV tuner. 

johnsfine: Thanks for looking at these. If you have time later in the week to tweak a protocol for these unusual gaps, I would love to try it out. I really want to use this on a 2116 (LCD remote), not the 1994 that I uploaded. (I understand the protocol code is different for LCD & non-LCD UEI remotes?) 

Thanks, both of you, for looking at this. 

Joe 
 
--------------------------------------------------------------------------------
jon_armstrong
 Posted: Mon Feb 16, 2004 2:44 pm    Post subject:    
--------------------------------------------------------------------------------
 
Joe, 

I just posted a file created by Protocol Builder to produce exactly two commands with the longer gap between commands. It is in the diagnosis area as NetCommands.zip. 

There are three files. 1994.txt is the image from my 1994 and the commands are on the exact same keys as you learned them but on the cable device. All you need to do is load that image in your 1994 and test. 

If that works then there is a KM Master file that has the device and protocol upgrade and a PB file just FYI or in case you want or need to tweak the protocol. 

For any astute Mitsubishi protocol experts I reversed the One/Zero definitions so that Mitsubishi TV_0150 EFC's work although the KM Master file is set up to use OBC's. 

Joe, uif this works you can actually clear all the assigned keys in the functions tab and add the "keyless" device upgrade using IR and then use key moves to place the keys where you want them in your TV device. 

John, FYI if you are watching this thread I am pretty sure that the "forced" choice on PB (and I checked back as far as v1.15 doesn't work as advertised). I used minimum=2/repeat=None and get exactly two repeats even when used in a macro (which is what we want in this case but, I don't think it is supposed to work this way).
_________________
-Jon 
 
--------------------------------------------------------------------------------
johnsfine
 Posted: Mon Feb 16, 2004 5:14 pm    Post subject:    

--------------------------------------------------------------------------------
 
jon_armstrong wrote: 

I just posted a file created by Protocol Builder to produce exactly two commands with the longer gap between commands. 


I thought the shorter gap was supposed to go between the first two frames and then the longer gap before the third. 

I assume your intent was just to get rid of the learned signals for the commands that don't need to repeat while held. It doesn't address the ones that need repeat while held. 

jon_armstrong wrote: 

John, FYI if you are watching this thread I am pretty sure that the "forced" choice on PB (and I checked back as far as v1.15 doesn't work as advertised). I used minimum=2/repeat=None and get exactly two repeats even when used in a macro (which is what we want in this case but, I don't think it is supposed to work this way). 


It's not likely that I'll ever have time to chase that down. Sorry. 
--------------------------------------------------------------------------------
jdoss
 Posted: Mon Feb 16, 2004 5:46 pm    Post subject:     

--------------------------------------------------------------------------------
 
johnsfine wrote: 
I assume your intent was just to get rid of the learned signals for the commands that don't need to repeat while held. It doesn't address the ones that need repeat while held. 


Jon, 

I tried the file you uploaded, and as John said above, it does behave exactly like the keys I learned with "tap & release". Each key is seen as exactly one keypress by the TV, and I verified that the TV_0150 EFCs work correctly. None of these repeat when held down, so I am still looking for that feature for the arrow keys, but this should help free-up learned memory in the remote. 

Does KM automatically translate protocol upgrades from non-LCD to LCD remotes? (S3C8 to S3C8+?) I loaded your device upgrade into KM, and then changed the remote from 1994 to 2116, and noticed it changed the last two hex numbers of the protocol code, but I haven't actually tried it in the 2116 yet. 

Thanks again for your help. 

Joe 
--------------------------------------------------------------------------------
johnsfine
 Posted: Mon Feb 16, 2004 6:06 pm    Post subject:    

--------------------------------------------------------------------------------
 
jdoss wrote: 

Does KM automatically translate protocol upgrades from non-LCD to LCD remotes? (S3C8 to S3C8+?) 


KM does automatically translate protocols for the two different S3C80 models. 

It is not non-LCD vs LCD, since the non-LCD remotes have had the same S3C80 as the LCD models for quite a while. Also, IIRC, KM translates from new to old, not from old to new, so that upgrade must have new S3C80 code pasted in, which KM leaves untouched where it was pasted, but translated for the 1994 where it redisplayed it. When you changed models, you were effictively turning that translation off. 
 
Back to top        
 
 
--------------------------------------------------------------------------------
jon_armstrong
 Posted: Mon Feb 16, 2004 8:48 pm    Post subject:    

--------------------------------------------------------------------------------
 
I think we can just use PB with a mid frame gap for the repeating arrow commands. four 8-bit bytes of fixed data and one byte of variable data and the mini combiner; a little ugly but for only four keys that is not too bad. I'll post that tomorrow. 

I have edited this a couple of times to try and get the number of data bits correct!
_________________
-Jon

 
--------------------------------------------------------------------------------
pH7_jp1
 Posted: Tue Feb 17, 2004 5:28 am    Post subject:    

--------------------------------------------------------------------------------
 
THANKS to everyone for digging into this. I have been living with this irratation on my Mits TV for quite a while. I don't use the NetCommand feature, but the arrow keys still have this problem when in some of the menus. It will be great to have it working right. 
--------------------------------------------------------------------------------
jon_armstrong
 Posted: Tue Feb 17, 2004 10:49 am    Post subject:    

--------------------------------------------------------------------------------
 
I have posted a file Mitsubishi NetCommands Arrows.zip in the diagnosis area. Same as before, I have included the 1994 EEPROM image and the arrows are on the TV device on the arrows. Let us know if this works. The PB and KM Master files are also there.
_________________
-Jon 
 
 
--------------------------------------------------------------------------------
jdoss
 Posted: Tue Feb 17, 2004 11:16 pm    Post subject:     

--------------------------------------------------------------------------------
 
jon_armstrong wrote: 
I have posted a file Mitsubishi NetCommands Arrows.zip in the diagnosis area. 


I tried it out, and it seems to work almost the same as TV_0150: 
- Each single press is seen as two keypresses 
- It does repeat, but much slower than the original remote. 

With the original remote, the TV accelerates scrolling through the "recording start time", going faster the longer the up or down key is held down. It also accelerates about the same with TV_0150. With this 0115 protocol, it scrolls at a constant rate, like it sees approximately 5 individual keypresses per second, but does not see the key is held down. 

It occurs to me that the timings might be more accurately captured by a Philips Pronto than from the UEI remotes. I don't have a Pronto to test it, but it looks like this file has some fairly long captures of the Netcommand arrow keys: http://mine.remotecentral.com/ftp/ccf_templates/complete_system/don-cole_ccf.zip 

Ccf2efc decodes the arrow keys in there as 3 or 4 repeats of "Mitsubishi:71:XXX". I don't know if this helps or not. 

Thanks again for your work on this. 
Joe 
 
--------------------------------------------------------------------------------
jon_armstrong
 Posted: Wed Feb 18, 2004 11:53 am    Post subject:    

--------------------------------------------------------------------------------
 
This gets more curious. I decoded the Pronto hex file from the link and here is what the arrow keys do: 

All have the SAME gap between frames. It looks like the final off time is such that the total frame length is 53.4 mS. 

Down -- 4 repeats of 71:73 
Left -- a fragment and 4 repeats of71:101 
Right -- 5 repeats of 71:109 
Up -- fragment and 2 repeats of 71:065 

Each of these commands are learned as a one time command (not repeating). 

I started to suspect that maybe the interpretation of two commands is due to the gap between frames being too long. The ccf file has gaps between frames from 23 mS to 26 mS and I learned some TV_0150 commands from my 7800 with Tommy Tyler's IR Analyzer. The power command has a 28mS gap between frames. (incorrect information edited out) 

Let's try this as an experiment, key move: 

UP EFC 169 
DN EFC 041 
LT EFC 200 
RT EFC 072 

To both Numerals 1 through 4 AND the cursor keys. (The commands on the built in setup code are not the cursors you learned) 

See if either of those work. [The numeral keys will have the altenating short and long gap between frames -- note:this is incorect I was lookin at keys with learned data on them]. The cursor keys will be nearly exactly like the ccf file. 

John, Rob, others any better ideas?
_________________
-Jon


--------------------------------------------------------------------------------
jon_armstrong
 Posted: Thu Feb 19, 2004 1:06 pm    Post subject:    

--------------------------------------------------------------------------------
 
jdoss wrote: 
jon_armstrong wrote: 
Let's try this as an experiment, key move: 

UP EFC 169 
DN EFC 041 
LT EFC 200 
RT EFC 072 

To both Numerals 1 through 4 AND the cursor keys. 
See if either of those work.  


You did mean using the regular TV_0150 protocol, right?  


Yes 

Quote: 
I did the keymoves above, using TV_0150, to arrows and to numeric keys. I get exactly the same behavior from both groups of keys � Single keypresses are seen as two, keys held down give correct repeating behavior � fast scrolling, accelerating the longer the key is held down. 


That the behavior is identical on the numerals or cursor keys is correct. I had convinced myself in testing that the regular Mitsubishi protocol had a variation with the alternating gap between frames on the number keys. That was incorrect since I was decoding keys where I had learned commands from testing the previous protocol where I created the altenating gap! 

I went back and downloaded most of the ccf files from Mitsubishi RPTV's that had WS-XXXXX and ALL the arrow keys are the same and do NOT have the alternating gap. So I have created another set of files (Mitsubishi NetCommand Frame 53.6 mS.zip) to test where I shortended up the gap between frames. 

It is now set for a total frame length of 53.6 mS. The frames in TV_0150 are 2 to 3 mS longer and that MAY be why it keeps recognizing those commands as two seperate commands. 

If that doesnt work, you can open the Mitsubishi_NetCommand-frame set to 53.6mS-PB.txt with Protocol Builder and adjust the timing in cell E19. First try it shorter and then longer. Increments of 1000 uS should be OK. 

That sets the value of the total frame length. The 16 bits of data take up approximately hte first half frame and the remainder is a big off time aka Gap. Often the gap the TV to determine if it is a repeat of the old command or a new one. 

If that still doesn't work, then go back to the set of files for the arrows and open Mitsubishi_NetCommand-PB-arrows.txt with PB and start adjusting cells E16 which controls the gap between the first two frames and E19 that contols the second gap. 

In theory, shortening E19 shouild make the repeats faster and shortening E16 should make it less likely to interpret those commands as two commands rather than one. 

In either case when using PB, you should make the changes then find the corresponding KM Master file and copy and paste special into the notes section of KM Master. Then you must copy the Protocol upgrade from S3C8 Protocol box into IR. KM Master converts the generic protocol generated from PB into that needed by the specific remote.
_________________
-Jon 
 
--------------------------------------------------------------------------------
jdoss
 Posted: Thu Feb 19, 2004 7:11 pm    Post subject:     

--------------------------------------------------------------------------------
 
jon_armstrong wrote: 
I have created another set of files (Mitsubishi NetCommand Frame 53.6 mS.zip) to test where I shortended up the gap between frames. 

It is now set for a total frame length of 53.6 mS. The frames in TV_0150 are 2 to 3 mS longer and that MAY be why it keeps recognizing those commands as two seperate commands. 
 

So far, in limited testing, that seems to work perfectly, no adjustments required. (Yay!!!) 

I will go ahead and add all the keys to the KM file, test it a little more, and then upload it to the devices area, so others like "pH7_jp1" can grab a full working device upgrade. 

Thank you so much for your effort! I really appreciate it. 
Joe 
 
Back to top       
 
 
--------------------------------------------------------------------------------
jon_armstrong
 Posted: Thu Feb 19, 2004 10:27 pm    Post subject:    

--------------------------------------------------------------------------------
 
BTW, assuming it does what you need, you should be able to use that protocol and device upgrade for all the regular commands as well -- so you can get it all into one device upgrade. The new protocol is very close to the built in protocol, but that one is apparently a little too long. 

Assuming it all works, you might post the "TV_0150 upgrade" probably name it TV_1150 with the new protocol and all the discretes along with an explanation since I will probably forget all the details in a month. 

Glad we made some progress on this!
_________________
-Jon 
 
--------------------------------------------------------------------------------
scottamus
 Posted: Sat Feb 21, 2004 6:26 pm    Post subject:    

--------------------------------------------------------------------------------

Hi, I'm a complete noob to this jp1 stuff. in fact this is my first post. I just built my jp1 cable last night and downloaded the "Mitsubishi WS-55809 TV.txt" KM file and ul'ed to my new 8811. I found this exact same problem with the arrows double jumping and low and behold stumbled onto this thread. 

I'm glad to hear that you already seem to have fixed the problem before I even knew there was one! I found a file "NetCommand.zip" on the jp1 groups which had arrows that worked great. Although I haven't figured out how to combine them with the TV device. But I'm sure I'll figure that out eventually. 

Anyway, I guess I just want to say your efforts are appreciated. 
 
--------------------------------------------------------------------------------
scottamus
 Posted: Mon Feb 23, 2004 3:31 am    Post subject:    

--------------------------------------------------------------------------------
 
I think I'm getting the hang of this. I've discovered discrete codes for the inputs not listed in the "Mitsubishi WS-55809 TV.txt" KM file and have added them to a new file for my 55859. These include input-5, comp-2, and VGA. I also added an A/V reset I came across in avsforum but I'm scared to actually try it. I was thinking of adding your arrow keys to the list but because they are a different protocol I'm not sure how to put them in my new KM file. 

funct= EFC 
Comp2= 201 
Input 5= 233 
VGA= 153 
A/V Reset= 059 
 
Back to top       
 
 
jon_armstrong
Expert


Joined: 03 Aug 2003
Posts: 337

 Posted: Mon Feb 23, 2004 7:56 am    Post subject:    

--------------------------------------------------------------------------------
 
Here is a list of Mitsubishi TV/RPTV commands from my files. Not every command works on all models. You should be able to use any of these in the last device upgrade file that I posted in the diagnostics area (Mitsubishi NetCommand Frame 53.6 mS.zip). 

The device upgrade in the zip file, Mitsubishi NetCommand Frame 53.6 mS-KM.txt, already has the upgraded protocol that will make the arrows work correctly. That Device/Protocol upgrade should work for any of these commands since it corrects the built in protocol to a shorter frame length. What this means is that you don't need to create seperate device upgrades. You will need to copy and paste both the Device AND Protocol upgrade into IR. 

The Mitsubishi NetCommand Frame 53.6 mS-PB.txt is FYI and you don't need to do anything with it since it is used with Protocol Builder and I have already put it in the right place in the device upgrade. 

FYI, the device upgrade is set up to use OBC (not EFC) but I have included both in the list below so you have a cross reference. 

Since I don't have any Mitsubishi gear I can't tell you if any of these commands will get you in a service mode or do something like erase your settings. I have not heard of any problems. Ususally people will note any problem commands when they post them. 

OBC EFC Function 
000 181 1 
001 185 9 
002 183 POWER 
007 186 CANCEL 
008 053 2 
009 057 0 
010 055 CH + 
011 059 A/V Reset 
015 058 Ant A/B Toggle (will switch from other Input1-4) 
016 117 3 
018 119 CH - 
023 122 SLEEP 
024 245 4 
026 247 Input- 
027 251 INFO/Display 
032 213 5 
034 215 VOL + 
040 085 6 
042 087 VOL - 
048 149 7 
049 153 VGA 
050 151 MUTE 
052 148 Right 
053 152 Enter 
054 150 MOVE 
056 021 8 
058 023 TV/VCR, Input+ 
060 020 Left/SELECT 
062 022 Zoom Toggle/ FORMAT 
064 165 Vid 
065 169 Up Arrow 
066 167 Power On 
069 168 INSTALL 
072 037 Video 
073 041 Down Arrow 
074 039 Power Off (also EFC 189--OBC 128) 
076 036 Ant B 
080 101 ENTER/Audio (also EFC 229--OBC 88) 
082 103 MENU 
088 229 Audio 
089 233 STB 
090 231 Ant A 
091 235 EXIT 
097 201 Component 2 
098 199 Input 1 
099 203 GUIDE 
101 200 Left Arrow 
103 202 PiP Freeze 
105 073 Component 1 
106 071 Input 2 
109 072 Right Arrow 
111 074 Zoom Toggle (also EFC 022 --OBC 62) 
113 137 ALTERNATE INPUT/DTV1 
114 135 Input 3/DVD 
119 138 PiP On/Off 
119 138 PIP 
121 009 DTV Input 
122 007 Input 4/Front 
127 010 SWAP 
128 189 Power Off
_________________
-Jon 
 

 
 
