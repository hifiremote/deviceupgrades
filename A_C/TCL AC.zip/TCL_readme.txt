TCL/Kwiik Air Conditioners

The signals for these A/C units include all the settings, so even though you have buttons like TEMP+ and TEMP- on the original remote, we can't replicate those here, you have to chose how you want all the settings to be in each signal.

The functions included in the RMDU file here are for reference only, you can create your own unique list of custom functions where the various A/C attributes are set to your preferences.  Before using RM, check whether the [TCL A/C] protocol is present in protocols.ini and if it isn't, add the code from below.

Any questions, please post them in the forum.
http://www.hifi-remote.com/forums/viewtopic.php?t=102534 (Kwiik)
http://www.hifi-remote.com/forums/viewtopic.php?t=16473  (TCL)

Thanks,
Rob

[TCL A/C]
PID=01 FF
VariantName=JP1TCL
CmdParms=mode sw:Off|On=1,mode:-|heat|dry|cool|-|-|-|fan|feel=1, \
    temp C:16C|17C|18C|19C|20C|21C|22C|23C|24C|25C|26C|27C|28C|29C|30C|31C=0, \
    temp F:61F|63F|64F|66F|68F|70F|72F|73F|75F|77F|79F|81F|82F|84F|86F|88F=0, \
    swing:Off|On=0,fan:auto|sleep|low|med|-|high=0,time sw:Off|On=0, \
    time:0|10m|20m|30m|40m|50m|1h|1h 10m|1h 20m|1h 30m|1h 40m|1h 50m \
        |2h|2h 10m|2h 20m|2h 30m|2h 40m|2h 50m|3h|3h 10m|3h 20m|3h 30m|3h 40m|3h 50m \
        |4h|4h 10m|4h 20m|4h 30m|4h 40m|4h 50m|5h|5h 10m|5h 20m|5h 30m|5h 40m|5h 50m \
        |6h|6h 10m|6h 20m|6h 30m|6h 40m|6h 50m|7h|7h 10m|7h 20m|7h 30m|7h 40m|7h 50m \
        |8h|8h 10m|8h 20m|8h 30m|8h 40m|8h 50m|9h|9h 10m|9h 20m|9h 30m|9h 40m|9h 50m \
        |10h|10h 10m|10h 20m|10h 30m|10h 40m|10h 50m|11h|11h 10m|11h 20m|11h 30m|11h 40m|11h 50m \
        |12h|12h 10m|12h 20m|12h 30m|12h 40m|12h 50m|13h|13h 10m|13h 20m|13h 30m|13h 40m|13h 50m \
        |14h|14h 10m|14h 20m|14h 30m|14h 40m|14h 50m|15h|15h 10m|15h 20m|15h 30m|15h 40m|15h 50m \
        |16h|16h 10m|16h 20m|16h 30m|16h 40m|16h 50m|17h|17h 10m|17h 20m|17h 30m|17h 40m|17h 50m \
        |18h|18h 10m|18h 20m|18h 30m|18h 40m|18h 50m|19h|19h 10m|19h 20m|19h 30m|19h 40m|19h 50m \
        |20h|20h 10m|20h 20m|20h 30m|20h 40m|20h 50m|21h|21h 10m|21h 20m|21h 30m|21h 40m|21h 50m \
        |22h|22h 10m|22h 20m|22h 30m|22h 40m|22h 50m|23h|23h 10m|23h 20m|23h 30m|23h 40m|23h 50m|24h=0
CmdTranslator=Translator(0,1,16) Translator(1,4,0) Translator(2,4,4,comp) Translator(3,4,4,comp) \ 
    Translator(4,1,18) Translator(4,1,19) Translator(4,1,20) Translator(5,3,21) Translator(6,1,17) Translator(7,8,8)
DefaultCmd=00 00 00
CmdIndex=0
FixedData=
Notes=This is a protocol for TCL and similar air conditioners.  The mode_sw and time_sw parameters are On/Off switches for mode and time \
that have their values as separate parameters.
Code.S3C80=43 8C 03 8B 17 00 00 CD 00 B9 07 08 03 0C 00 00 00 00 00 00 00 00 08 00 01 26 CB 23 E4 03 20 E4 03 21 F0 21 56 20 0F 56 21 0F C4 04 1E 56 1F 7F 18 05 10 C1 C0 22 10 C1 C0 22 F0 22 1C 16 F6 01 4C 6C 0E 87 36 19 5C 08 1C 12 F6 01 4C 37 30 07 C6 F8 01 9A F6 01 58 E0 C3 5A ED 04 C3 1A 6A E3 1C 12 F6 01 4C AF 

