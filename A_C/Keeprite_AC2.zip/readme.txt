Add this to protocols.ini before use.

[Keeprite A/C]
PID=01 FE
VariantName=JP1KR
CmdParms=Mode:Auto|Cool|Dry|Fan|Heat=0, \
    Power1:Off|On=1, \
    Fan:Auto|Low|Med|High=0, \
    Unknown:Off|On=0, \
    Sleep:Off|On=0, \
    Temp C:16C|17C|18C|19C|20C|21C|22C|23C|24C|25C|26C|27C|28C|29C|30C=0, \
    Temp F:61F|63F|64F|66F|68F|70F|72F|73F|75F|77F|79F|81F|82F|84F|86F=0, \
    Turbo:Off|On=0, \
    Light:Off|On=0, \
    Power2:Off|On=1, \
    Swing style:Off|Full|Pos1|Pos2|Pos3|Pos4|Pos5|Bottom|-|Middle|-|Top=0, \
    Temp display:Off|Indoor Set|Indoor Ambient|Outdoor Ambient=0, \
    Main Power:On|Off=0
CmdTranslator=Translator(LSB,0,3,0) Translator(LSB,1,1,3) Translator(LSB,2,2,4) Translator(LSB,3,1,6) Translator(LSB,4,1,7) \ 
    Translator(LSB,5,4,8) Translator(LSB,6,4,8) Translator(LSB,7,1,12) Translator(LSB,8,1,13) Translator(LSB,9,2,14) \
    Translator(LSB,10,4,16) Translator(LSB,12,1,20) Translator(LSB,11,3,21) 
DefaultCmd=00 00 00
CmdIndex=0
FixedData=
Notes=
Code.S3C80=43 8C 03 8B 12 8F 44 08 03 01 45 03 31 01 45 01 06 27 10 11 A7 08 B7 C6 10 04 01 18 05 E4 04 05 56 04 F0 56 05 0F C6 06 0A 40 19 08 56 08 F0 F0 C1 10 C1 FB 06 46 04 05 46 05 80 19 09 56 09 C0 46 09 02 5C 0E 1C 04 87 31 02 F6 FF 73 02 54 1A F6 38 C5 F6 FF 73 F0 C4 56 C4 0F 49 0A F6 01 46 B0 13 E6 29 40 E4 08 03 E4 09 04 B0 05 E4 0A 06 8D 01 46 2C 08 10 C3 C0 C4 2A FA AF

