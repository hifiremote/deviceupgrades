Seville Ultraslimline tower fan
-------------------------------

The remote signals for this fan have all of the various settings built into them, so you need to decide in advance what you want each button press to do.

The included spreadsheet will generate the correct code based on your selections.

You can then cut & paste columns A and B from the spreadsheet into columns A and B of the Functions sheet of the KM upgrade.  Please note that, because of the cell protections in KM, you cannot paste the heading line.  

Also, when you paste the data, select "Paste Special" and then select "Values".

Rob
rob1@rockabilly.net

ps. The PB file is included just for reference, you don't need to do anything with it.