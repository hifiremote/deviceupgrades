Dish Network Combo with dynamic unit selection
2/2/2007
===================================================================

This scheme permits changing the DISH unit (address) without making
separate upgrades. It's done on the fly by use of Advanced Select special protocol.

The entire thing is adapted from the same idea for TiVo written
by Hal Takahara. 
The original file, worth reading is "TiVo_dynamic_unit_sel.txt". 
It is in the files section http://www.hifi-remote.com/forums/dload.php?action=file&file_id=1756
with a note: 
"Custom protocols for TiVo that allow you to switch the unit code by a key press and use a single device upgrade for multiple units of the same type."

We do the same for DISH, based on a recent discussion
http://www.hifi-remote.com/forums/viewtopic.php?t=7803

===================================================================

The text of protocols listed here is included in the Notes column in the KM file for 6131ext.

1.  If starting from scratch, skip point 2.

2.  Modify existing IR setup (cleanup)

2a.  If IR contains more than one Dish device upgrade for different units,
delete all but one. Also cleanup General tab setup codes assignments.

2b.  IF IR already has a previously created Dish Network Combo protocol
visible (0002) delete it and replace with the protocol from here.

2c.  Clean up keymoves and macros which use now deleted setup code(s). 
Adjust others accordingly. Don't forget X_dev assignments in macros and
on the Special Protocols sheet.

3.   Copy and paste to IR the DISH Network Combo protocol with "rBF in name".
This replaces the built-in protocol (or in case of other remotes, a protocol 
supplied by KM or RM automatically).
In addition to allowing on the fly change, this protocol increases number of repeats.
The "03" just left of "43 8C" in the middle line is the change point. 
Original was 02, not sufficient for use in macros.

Upgrade protocol 0 = 00 02 (S3C8+) DishNetworkCombo-rBF (PB v4.00)
 2B 5C 51 8B 16 B6 59 05 06 00 C5 03 32 00 C5 05 
 73 0B F2 00 C5 0B F2 05 03 43 8C E4 BF 03 56 03 
 F0 18 08 56 C1 03 87 21 04 29 04 8D 01 46
End

4.  Copy and paste to IR device upgrade and add Advanced Select Protocol

Upgrade code 0 = 0C 51 (SAT/1105) Advanced Select (Special)
 FA 00 01
End
Upgrade protocol 0 = 01 FA (S3C8+) Advanced Select (Special)
 00 00 02 F5 04 03 AF
End

5.  Create switching keymoves, for instance on SAT/shift-1, SAT/shift-2 ...

Bound Key: (use Device/Key of your choice)
Device Type/Setup Code: SAT/1105
Hex Cmd: $BF $xxx

where xxx=hex code (LSB 0-15) corresponding to DISH address units 1-16. Examples:

Keymove hex bytes to select Unit1  $BF $00
Keymove hex bytes to select Unit2  $BF $80
Keymove hex bytes to select Unit3  $BF $40
Keymove hex bytes to select Unit4  $BF $C0
Keymove hex bytes to select Unit14  $BF $B0
Keymove hex bytes to select Unit16  $BF $F0
for others, look up in KM or RM.

6.  To the device key macros, after making O_keys active, insert the switching keymoves
Or make global macros to do the same.
Or just use the keymoves directly prior to using the desired Dish unit.
Whatever is convenient. Whatever works best for YOUR setup.

7.  Upload to remote.

8.  Since register $BF is undefined on reset, press one of the keymoves to initialize it.

9.  Reminder: For DISH to hear the remote, the DISH receiver address and the remote must match.


