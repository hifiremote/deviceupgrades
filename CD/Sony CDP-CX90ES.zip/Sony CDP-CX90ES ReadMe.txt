Sony CDP-CX90ES 200-CD Changer Setup (Keymap Master v5.04b)
Mike England (mr_d_p_gumby)

This ZIP file contains three setups for the Sony changers.

If your changer has a switch to select the remote code
as CD1, CD2 or CD3, use the appropriate setup sheet.

If your changer does not have a switch, then the sheet
for CD3 will probably be the correct one to use.

The button codes in these setup sheets were obtained from
several different Sony 200-CD changer models, and will
probably work for most Sony changers, though newer models
may have additional functions that you will have to
research.
