nVidia Shield Pro 2019 via Flirc 2nd Gen

Load the .fcfg file into the Flirc software with the Flirc connected to your PC,
andl load the .rmdu file into RMIR and configure buttons as desired.

All of the original buttons on the Shield remote are represented, except of course, the MIC button, which is not possible on an IR remote.

2022/02/21