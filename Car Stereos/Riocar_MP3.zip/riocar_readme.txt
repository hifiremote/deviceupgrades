
riocar_readme.txt - Notes on Upgrade Code for the Sonic Blue RioCar/Empeg Remote

I've included the CSV dump file from the KM5.05

Notes:
1) I setup the remote as a "DVD" device in order to be able to map more of the buttons as part of the remote.  Using "CD" prevented using the PIP controls, which I wanted to use as Info, Display, etc.  If you have an alternate mapping in mind, you can certainly get away with using "CD" device.

2) Due to using "DVD" as the device, I am precluded from using the "Surround" button, I suggest using a KeyMove to map EFC 058 ("Sound" on the RioCar Mk2 remote) to cover this function.  This sets up the entire remote requiring only one KeyMove.  You could do it another way but other moves might be required.

3) This seems to work with all of my usage of my RioCar in my home A/V rack, but I expect a "power user" may do more using the HiJack kernel's  support for Ir Remap, etc.

4) Upon reloading the CSV file into KM you may notice that some of the EFCs have been mapped redundantly, (such as mute, play, and pause all send the play/pause button, etc.) this was mainly so my wife could hit any button that might make sense at the time and probably end up with the desired result! ;-)

5) BTW, I used code "1027" since TV 0027 was a match as far as protocol and device code, but the mapping of buttons is way off to be usable with the Rio/Empeg.

Hope that helps, please email me if any questions.

Mike 'Herbie' Herbst
herbie@san.rr.com