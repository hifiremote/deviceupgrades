INSTALLATION
============
Please follow the instructions at:  

http://placeshiftingenthusiasts.com/how-to-install-a-custom-remote-onto-the-slingbox/  

(And please read them in full, I waste a lot of time with people who haven't bothered)

REMOTE IMAGE
============
This file will use the basic, default, remote image.  If you know of a built-in remote that actually displays a realistic remote then go back on the forum and I will see what I can do. 

But if you want a much better remote 'skin' which does include the Custom Buttons, then check out this thread:  http://placeshiftingenthusiasts.com/customising-the-remote-image-on-your-slingplayer/

Alan Richey