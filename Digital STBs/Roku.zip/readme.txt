Copy/paste the text below into Protocols.ini to use the new official Roku protocol if it is missing from your version.

[Roku Official] 
PID=02 1A 
DevParms=Device Number=234,Sub Device=194 
DeviceTranslator=Translator(lsb,0,8,0) Translator(lsb,1,8,8) 
CmdParms=OBC:7 
CmdTranslator=Translator(lsb) 
FixedData=FF FF 
Code.S3C80=43 8B 21 8B 12 CF 44 08 08 01 21 03 30 01 21 00 FD D2 DC 11 94 08 B6 E4 05 06 60 06 20 11 F6 01 46 F6 01 0A 7B 01 AF 46 05 01 56 06 FE 46 29 01 8D 01 46 
Code.MAXQ610=33 69 21 0E 16 00 44 03 16 00 12 01 F0 D2 56 01 CA 08 40 80 04 15 D3 D2 01 62 44 44 70 71 72 F2 62 54 04 70 71 73 F3 
Notes=This IR protocol is very similar to NEC2, except the OBCs are limited to the range 0-127 and the repeat behavior is different.  The second and additional frames of a repeating signal send the OBC + 128.  